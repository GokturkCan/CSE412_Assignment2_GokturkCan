import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    
    pkg_description = get_package_share_directory('my_robot_description')
    pkg_gazebo = get_package_share_directory('my_robot_gazebo')
    
    urdf_file = os.path.join(pkg_description, 'urdf', 'my_robot.urdf.xacro')
    world_file = os.path.join(pkg_gazebo, 'worlds', 'ball_world.sdf')
    
    # Robot description
    robot_description_content = Command(['xacro ', urdf_file])
    robot_description = {'robot_description': ParameterValue(robot_description_content, value_type=str)}
    
    # Gazebo Sim
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', world_file, '-r'],
        output='screen'
    )
    
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description, {'use_sim_time': True}]
    )
    
    # Joint state publisher
    joint_state_publisher = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )
    
    # Spawn robot
    spawn_robot = TimerAction(
        period=5.0,
        actions=[
            Node(
                package='ros_gz_sim',
                executable='create',
                arguments=[
                    '-topic', '/robot_description',
                    '-name', 'my_robot',
                    '-x', '0',
                    '-y', '0',
                    '-z', '0.2'
                ],
                output='screen'
            )
        ]
    )
    
    # Bridge for cmd_vel
    bridge_cmd_vel = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist'],
        output='screen'
    )
    
    # Bridge for camera
    bridge_camera = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/camera/image_raw@sensor_msgs/msg/Image@gz.msgs.Image'],
        output='screen'
    )
    
    # Bridge for odometry
    bridge_odom = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/odom@nav_msgs/msg/Odometry@gz.msgs.Odometry'],
        output='screen'
    )
    
    # RViz
    rviz = TimerAction(
        period=7.0,
        actions=[
            Node(
                package='rviz2',
                executable='rviz2',
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    # Ball chaser node
    ball_chaser = TimerAction(
        period=10.0,
        actions=[
            Node(
                package='ball_chaser',
                executable='ball_chaser_node',
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )
    
    # TF view frames
    view_frames = TimerAction(
        period=12.0,
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'run', 'tf2_tools', 'view_frames'],
                output='screen'
            )
        ]
    )
    
    return LaunchDescription([
        gazebo,
        robot_state_publisher,
        joint_state_publisher,
        spawn_robot,
        bridge_cmd_vel,
        bridge_camera,
        bridge_odom,
        rviz,
        ball_chaser,
        view_frames
    ])
