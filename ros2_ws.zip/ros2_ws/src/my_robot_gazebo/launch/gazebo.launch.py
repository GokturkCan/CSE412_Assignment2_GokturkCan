import os
from launch import LaunchDescription
from launch.actions import ExecuteProcess, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    
    pkg_my_robot_gazebo = get_package_share_directory('my_robot_gazebo')
    pkg_my_robot_description = get_package_share_directory('my_robot_description')
    
    world_file = os.path.join(pkg_my_robot_gazebo, 'worlds', 'ball_world.sdf')
    urdf_file = os.path.join(pkg_my_robot_description, 'urdf', 'my_robot.urdf.xacro')
    
    # Process URDF
    robot_desc = ExecuteProcess(
        cmd=['xacro', urdf_file],
        output='screen'
    )
    
    # Gazebo server
    gazebo_server = ExecuteProcess(
        cmd=['gz', 'sim', '-r', '-s', world_file],
        output='screen'
    )
    
    # Gazebo client
    gazebo_client = ExecuteProcess(
        cmd=['gz', 'sim', '-g'],
        output='screen'
    )
    
    # Spawn robot
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-file', urdf_file,
            '-name', 'my_robot',
            '-x', '0',
            '-y', '0',
            '-z', '0.2'
        ],
        output='screen'
    )
    
    return LaunchDescription([
        gazebo_server,
        gazebo_client,
        spawn_robot
    ])
