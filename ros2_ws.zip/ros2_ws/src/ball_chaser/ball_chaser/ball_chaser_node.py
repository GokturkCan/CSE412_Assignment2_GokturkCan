#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import cv2
import numpy as np


class BallChaserNode(Node):
    def __init__(self):
        super().__init__('ball_chaser_node')
        
        # Publisher and Subscriber
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.image_sub = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            10
        )
        
        self.bridge = CvBridge()
        self.get_logger().info('Ball Chaser Node started!')
        
        # Parameters for ball detection
        self.center_tolerance = 50  # pixels
        self.linear_speed = 0.3
        self.angular_speed = 0.5
        
    def image_callback(self, msg):
        try:
            # Convert ROS Image to OpenCV format
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            
            # Convert to HSV for white color detection
            hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
            
            # Define range for white color in HSV
            lower_white = np.array([0, 0, 200])
            upper_white = np.array([180, 30, 255])
            
            # Create mask for white color
            mask = cv2.inRange(hsv, lower_white, upper_white)
            
            # Find contours
            contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
            
            twist = Twist()
            
            if len(contours) > 0:
                # Find the largest contour (assumed to be the ball)
                largest_contour = max(contours, key=cv2.contourArea)
                area = cv2.contourArea(largest_contour)
                
                # Only process if the contour is large enough
                if area > 500:
                    # Get the center of the contour
                    M = cv2.moments(largest_contour)
                    if M['m00'] > 0:
                        cx = int(M['m10'] / M['m00'])
                        cy = int(M['m01'] / M['m00'])
                        
                        # Get image dimensions
                        image_width = cv_image.shape[1]
                        image_center = image_width / 2
                        
                        # Calculate error from center
                        error = cx - image_center
                        
                        self.get_logger().info(f'Ball detected at x={cx}, error={error:.2f}')
                        
                        # If ball is in the center, move forward
                        if abs(error) < self.center_tolerance:
                            twist.linear.x = self.linear_speed
                            twist.angular.z = 0.0
                            self.get_logger().info('Moving forward')
                        # If ball is on the right, turn right
                        elif error > 0:
                            twist.linear.x = 0.0
                            twist.angular.z = -self.angular_speed
                            self.get_logger().info('Turning right')
                        # If ball is on the left, turn left
                        else:
                            twist.linear.x = 0.0
                            twist.angular.z = self.angular_speed
                            self.get_logger().info('Turning left')
                else:
                    # Ball too small or not detected
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
                    self.get_logger().info('Ball too far or not visible')
            else:
                # No ball detected, stop
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.get_logger().info('No ball detected - stopping')
            
            # Publish velocity command
            self.cmd_vel_pub.publish(twist)
            
        except Exception as e:
            self.get_logger().error(f'Error processing image: {str(e)}')


def main(args=None):
    rclpy.init(args=args)
    node = BallChaserNode()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
